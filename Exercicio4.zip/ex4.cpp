#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_TAM_PALAVRA 100

typedef struct {
    char palavra[MAX_TAM_PALAVRA];
    int frequencia;
} PalavraFrequencia;

int main() {
    FILE *arquivo_entrada, *arquivo_saida;
    char palavra[MAX_TAM_PALAVRA];
    PalavraFrequencia palavras[1000]; // Sup�e-se um m�ximo de 1000 palavras diferentes
    int num_palavras = 0;

    // Abrir o arquivo de entrada para leitura
    arquivo_entrada = fopen("texto.txt", "r");
    if (arquivo_entrada == NULL) {
        perror("Erro ao abrir arquivo de entrada");
        return EXIT_FAILURE;
    }

    // Ler o arquivo de entrada palavra por palavra
    while (fscanf(arquivo_entrada, "%s", palavra) != EOF) {
        // Converte a palavra para min�sculas
        for (int i = 0; palavra[i]; i++) {
            palavra[i] = tolower(palavra[i]);
        }

        // Verifica se a palavra j� foi encontrada anteriormente
        int encontrada = 0;
        for (int i = 0; i < num_palavras; i++) {
            if (strcmp(palavras[i].palavra, palavra) == 0) {
                // Incrementa a frequ�ncia da palavra
                palavras[i].frequencia++;
                encontrada = 1;
                break;
            }
        }

        // Se a palavra n�o foi encontrada, adiciona-a ao vetor de palavras
        if (!encontrada) {
            strcpy(palavras[num_palavras].palavra, palavra);
            palavras[num_palavras].frequencia = 1;
            num_palavras++;
        }
    }

    // Fechar o arquivo de entrada
    fclose(arquivo_entrada);

    // Abrir o arquivo de sa�da para escrita
    arquivo_saida = fopen("frequencia_palavras.txt", "w");
    if (arquivo_saida == NULL) {
        perror("Erro ao criar arquivo de sa�da");
        return EXIT_FAILURE;
    }

    // Escrever a frequ�ncia de cada palavra no arquivo de sa�da
    for (int i = 0; i < num_palavras; i++) {
        fprintf(arquivo_saida, "%s: %d\n", palavras[i].palavra, palavras[i].frequencia);
    }

    // Fechar o arquivo de sa�da
    fclose(arquivo_saida);

    printf("Frequ�ncia de palavras contada e salva com sucesso!\n");

    return EXIT_SUCCESS;
}
