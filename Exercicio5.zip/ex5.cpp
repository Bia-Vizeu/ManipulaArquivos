#include <stdio.h>
#include <stdlib.h>

#define DESLOCAMENTO 3 // N�mero de posi��es para deslocar cada caractere

int main() {
    FILE *arquivo_entrada, *arquivo_saida;
    char caractere;

    // Abrir o arquivo encriptado para leitura
    arquivo_entrada = fopen("texto_encriptado.txt", "r");
    if (arquivo_entrada == NULL) {
        perror("Erro ao abrir arquivo encriptado");
        return EXIT_FAILURE;
    }

    // Abrir o arquivo de sa�da para escrita
    arquivo_saida = fopen("texto_desencriptado.txt", "w");
    if (arquivo_saida == NULL) {
        perror("Erro ao criar arquivo de sa�da");
        return EXIT_FAILURE;
    }

    // Ler cada caractere do arquivo encriptado
    while ((caractere = fgetc(arquivo_entrada)) != EOF) {
        // Verificar se o caractere � uma letra min�scula
        if (caractere >= 'a' && caractere <= 'z') {
            // Deslocar o caractere para tr�s no alfabeto
            caractere = 'a' + (caractere - 'a' - DESLOCAMENTO + 26) % 26;
        }
        // Escrever o caractere desencriptado no arquivo de sa�da
        fputc(caractere, arquivo_saida);
    }

    // Fechar os arquivos
    fclose(arquivo_entrada);
    fclose(arquivo_saida);

    printf("Arquivo desencriptado com sucesso!\n");

    return EXIT_SUCCESS;
}
