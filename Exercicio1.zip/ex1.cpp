#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *arquivo1, *arquivo2, *arquivo_saida;
    char caractere;

    // Abrir o primeiro arquivo para leitura
    arquivo1 = fopen("arquivo1.txt", "r");
    if (arquivo1 == NULL) {
        perror("Erro ao abrir arquivo1.txt");
        return EXIT_FAILURE;
    }

    // Abrir o segundo arquivo para leitura
    arquivo2 = fopen("arquivo2.txt", "r");
    if (arquivo2 == NULL) {
        perror("Erro ao abrir arquivo2.txt");
        fclose(arquivo1);
        return EXIT_FAILURE;
    }

    // Abrir o arquivo de sa�da para escrita
    arquivo_saida = fopen("arquivo_saida.txt", "w");
    if (arquivo_saida == NULL) {
        perror("Erro ao criar arquivo_saida.txt");
        fclose(arquivo1);
        fclose(arquivo2);
        return EXIT_FAILURE;
    }

    // Copiar conte�do do primeiro arquivo para o arquivo de sa�da
    while ((caractere = fgetc(arquivo1)) != EOF) {
        fputc(caractere, arquivo_saida);
    }

    // Copiar conte�do do segundo arquivo para o arquivo de sa�da
    while ((caractere = fgetc(arquivo2)) != EOF) {
        fputc(caractere, arquivo_saida);
    }

    // Fechar os arquivos
    fclose(arquivo1);
    fclose(arquivo2);
    fclose(arquivo_saida);

    printf("Mescla de arquivos conclu�da com sucesso!\n");

    return EXIT_SUCCESS;
}
