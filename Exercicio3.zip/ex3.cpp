#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *entrada, *saida;
    char caractere;

    // Abrir o arquivo de entrada para leitura
    entrada = fopen("texto_original.txt", "r");
    if (entrada == NULL) {
        perror("Erro ao abrir arquivo de entrada");
        return EXIT_FAILURE;
    }

    // Abrir o arquivo de sa�da para escrita
    saida = fopen("texto_compactado.txt", "w");
    if (saida == NULL) {
        perror("Erro ao criar arquivo de sa�da");
        fclose(entrada);
        return EXIT_FAILURE;
    }

    // Ler o arquivo de entrada caracter por caracter
    while ((caractere = fgetc(entrada)) != EOF) {
        // Verificar se o caractere � um espa�o em branco ou quebra de linha
        if (caractere != ' ' && caractere != '\n') {
            // Escrever o caractere no arquivo de sa�da
            fputc(caractere, saida);
        }
    }

    // Fechar os arquivos
    fclose(entrada);
    fclose(saida);

    printf("Arquivo compactado com sucesso!\n");

    return EXIT_SUCCESS;
}
