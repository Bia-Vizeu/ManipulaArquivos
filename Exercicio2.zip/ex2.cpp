#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *entrada, *saida;
    char caractere, proximo;

    // Abrir o arquivo de entrada para leitura
    entrada = fopen("codigo_fonte.c", "r");
    if (entrada == NULL) {
        perror("Erro ao abrir arquivo de entrada");
        return EXIT_FAILURE;
    }

    // Abrir o arquivo de sa�da para escrita
    saida = fopen("codigo_sem_comentarios.c", "w");
    if (saida == NULL) {
        perror("Erro ao criar arquivo de sa�da");
        fclose(entrada);
        return EXIT_FAILURE;
    }

    // Ler o arquivo de entrada caracter por caracter
    while ((caractere = fgetc(entrada)) != EOF) {
        // Verificar se o caractere � um poss�vel in�cio de coment�rio
        if (caractere == '/') {
            proximo = fgetc(entrada);
            // Verificar se o pr�ximo caractere indica in�cio de coment�rio de linha
            if (proximo == '/') {
                // Ignorar todos os caracteres at� o fim da linha
                while ((caractere = fgetc(entrada)) != '\n' && caractere != EOF);
            }
            // Verificar se o pr�ximo caractere indica in�cio de coment�rio de bloco
            else if (proximo == '*') {
                // Ignorar todos os caracteres at� encontrar o fim do coment�rio de bloco
                while ((caractere = fgetc(entrada)) != EOF) {
                    if (caractere == '*') {
                        proximo = fgetc(entrada);
                        if (proximo == '/') {
                            break;
                        }
                    }
                }
            }
            // Caso contr�rio, escrever os caracteres normalmente no arquivo de sa�da
            else {
                fputc(caractere, saida);
                fputc(proximo, saida);
            }
        }
        // Caso contr�rio, escrever o caractere normalmente no arquivo de sa�da
        else {
            fputc(caractere, saida);
        }
    }

    // Fechar os arquivos
    fclose(entrada);
    fclose(saida);

    printf("Coment�rios removidos com sucesso!\n");

    return EXIT_SUCCESS;
}
